# -*- coding: utf-8 -*-
"""
Spyder Editor

Final Project script file.
"""


#import library
import numpy as np
import pandas as pd

from sklearn.pipeline import Pipeline

from sklearn.model_selection import train_test_split
from sklearn.preprocessing import OneHotEncoder
from sklearn.preprocessing import StandardScaler
from sklearn.compose import ColumnTransformer
from sklearn.decomposition import PCA

from sklearn.linear_model import LinearRegression  
from sklearn.ensemble import RandomForestRegressor

from sklearn import metrics


#import data
df = pd.read_excel('C:/Users/kally/Desktop/final project/data.xlsx')


#create new column
df['price_diff'] = df['TotalApprovedSalesPrice'] - df['SalePrice']


#drop the columns
df.drop(['id', 'Community', 'CommunityNumber', 'CommunityType', 'SaleNumber',
         'SaleDate', 'CloseDate', 'BasePrice', 'TotalApprovedSalesPrice',
         'LotNumber', 'LotAddress', 'LotCity', 'LotPostalCode', 'LotState',
         'CommunityLatitude', 'CommunityLongitude', 'CustomerFirstName',
         'CustomerLastName', 'CustomerPrimaryAddress', 'CustomerPrimaryCity',
         'CustomerPrimaryZipCode', 'CustomerPrimary State', 'Parcel', 'ZoningCode',
         'CobuyerContractFirstName', 'CobuyerContractLastName', 'Submarket',
         'CobuyerAddressLine1', 'CobuyerCity', 'CobuyerState', 'CobuyerZip',
         'MLSNumber', 'PlanNumber', 'SquareFeet', 'Bedrooms', 'Bathrooms',
         'Stories', 'GarageCapacity', 'Owner','Seller','TitleCompany','TranType',
         'Lender', 'Purchaser', 'SaleDate.1', 'DocumentNumber',
         'FinSF-Assessor-Based', 'DerivedSqFt Flag', 'SiteAddress'],axis=1,inplace=True)


#define threshold for dropping columns
df.isna().sum()
percent = int(0.7*(df.shape[0]))
df.dropna(thresh=percent, axis=1)


#separate the target variable and other features
X = df.drop(["price_diff"],axis=1)
y = df["price_diff"]


#split the train data and test data
Xtrain, Xtest, ytrain, ytest = train_test_split(X, y, test_size=0.2, random_state=1)

#ensure to work with a copy of the data
Xtrain = Xtrain.copy()
Xtest = Xtest.copy()
ytrain = ytrain.copy()
ytest = ytest.copy()


categorical_features = ['County', 'SiteCity', 'SiteZip', 'TranDesc', 'YrBuilt']
numeric_features=[ 'LotSF', 'FinSF', 'SalePrice', 'Stories.1']


#one-hot encoding on categorical features
categorical_transformer = Pipeline(steps=[('ohe', OneHotEncoder(sparse=False, dtype=int, handle_unknown='ignore'))])


#normalize the numeric features
numeric_transformer = Pipeline(steps=[('std', StandardScaler())])

preprocessor = ColumnTransformer(
    transformers=[
        ('num', numeric_transformer, numeric_features),
        ('cat', categorical_transformer, categorical_features)],
    remainder='drop') # remainder='passthrough')


print("--- Model for Predicting House Price ---\n")

#linear regression model with PCA
lr = Pipeline(steps=[('pp', preprocessor),("pca",PCA(n_components=8)),
                      ('lr', LinearRegression())])
lr.fit(Xtrain,ytrain)
ypred_lr = lr.predict(Xtest)

def LrScore():
    l = metrics.r2_score(ytest, ypred_lr)
    print("Linear Resgression:", l)

LrScore()    


#random forest model with PCA
rf = Pipeline(steps=[('pp', preprocessor),("pca",PCA(n_components=8)),
                      ('rf', RandomForestRegressor(n_estimators=10))])
rf.fit(Xtrain,ytrain)
ypred_rf = rf.predict(Xtest)

def RfScore():
    r = metrics.r2_score(ytest, ypred_rf)
    print("Random Forest:", r)

RfScore()


#find the best model
def FindModel():
    l = metrics.r2_score(ytest, ypred_lr)
    r = metrics.r2_score(ytest, ypred_rf)
    if l < r:
        print('\nRecommend Linear Regression as the model')
    else:
        print('\nRecommend Random Forest as the model')

FindModel()